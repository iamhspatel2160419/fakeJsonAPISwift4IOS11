package com.example.khean07.androiduberclone.Model;

/**
 * Created by Khean07 on 4/14/2018.
 */

public class Token {
    private String token;

    public Token() {
    }

    public Token(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
